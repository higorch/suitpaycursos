<?php

new class extends \Livewire\Component
{
    //
};
?>
