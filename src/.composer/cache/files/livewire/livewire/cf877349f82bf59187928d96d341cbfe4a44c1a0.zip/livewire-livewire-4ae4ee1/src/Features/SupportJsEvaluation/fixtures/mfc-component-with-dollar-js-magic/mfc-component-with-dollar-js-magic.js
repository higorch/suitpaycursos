$js('test', () => {
    window.test = 'through dollar js'
})
