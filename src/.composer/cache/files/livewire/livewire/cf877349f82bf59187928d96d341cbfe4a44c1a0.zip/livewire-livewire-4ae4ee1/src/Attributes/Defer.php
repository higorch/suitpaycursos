<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportLazyLoading\BaseDefer;

#[\Attribute]
class Defer extends BaseDefer
{
    //
}
