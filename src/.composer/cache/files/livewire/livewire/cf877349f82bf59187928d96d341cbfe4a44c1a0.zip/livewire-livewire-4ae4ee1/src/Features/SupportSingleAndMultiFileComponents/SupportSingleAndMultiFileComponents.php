<?php

namespace Livewire\Features\SupportSingleAndMultiFileComponents;

use Livewire\ComponentHook;

class SupportSingleAndMultiFileComponents extends ComponentHook
{
    static function provide()
    {
        //
    }
}
