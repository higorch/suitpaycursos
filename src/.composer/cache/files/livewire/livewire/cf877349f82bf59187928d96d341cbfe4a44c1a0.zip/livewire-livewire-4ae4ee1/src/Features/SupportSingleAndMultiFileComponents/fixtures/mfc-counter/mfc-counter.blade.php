<div>
    <span>Count: {{ $count }}</span>
    <button wire:click="increment">Increment</button>
</div>